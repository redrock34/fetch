//
//  ViewController.swift
//  chipotle
//
//  Created by John Zalubski on 6/25/20.
//  Copyright © 2020 John Zalubski. All rights reserved.
//
import UIKit
import CoreData
class ViewController: UIViewController {
    
    
    var foodItems = [Food]()
    var moc:NSManagedObjectContext!
    var appDelegate = UIApplication.shared.delegate as? AppDelegate
    var btn = UIButton()
    var lbl1 = UILabel()
  
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        moc = appDelegate?.persistentContainer.viewContext
        [btn,lbl1].forEach{
            view.addSubview($0)
            $0.translatesAutoresizingMaskIntoConstraints = false
        }
        
        
        NSLayoutConstraint.activate([
            
            btn.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.2),
            btn.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 1),
            btn.topAnchor.constraint(equalTo: view.topAnchor),
            btn.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            
            
            lbl1.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.2),
            lbl1.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 1),
            lbl1.topAnchor.constraint(equalTo: btn.bottomAnchor),
            lbl1.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            
          
            
        ])
        btn.backgroundColor = .orange
        lbl1.backgroundColor = .systemTeal
      
        btn.addTarget(self, action: #selector(addFoodToDatabase(_:)), for: .touchUpInside)
    }
    @objc func addFoodToDatabase(_ sender: UIButton) {
        let foodItem = Food(context: moc)
        foodItem.added = NSDate() as Date
        
        
        
        appDelegate?.saveContext()
        
        place()
        
    }
    func place(){
    let foodRequest:NSFetchRequest<Food> = Food.fetchRequest()
         
         // 2

         
         // 3
         do {
             try foodItems = moc.fetch(foodRequest)
             
         }catch {
             print("Could not load data")
         }
        lbl1.text = moc.name
      
         
    }
    
    
    
}



